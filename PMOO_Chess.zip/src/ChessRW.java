
public class ChessRW {
	public static void main(String[] args) throws InterruptedException {
		//Clase principal   	
		Tablero tablero = Tablero.getTablero();
		tablero.jugarPartida();

	}
}
