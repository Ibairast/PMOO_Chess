# ChessRW
Ajedrez implementada en Java para el proyecto grupal de Programación Modular y Orientación a Objetos
